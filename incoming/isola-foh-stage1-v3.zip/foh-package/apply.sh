#!/usr/bin/env bash
# Authoritative invocation:  bash apply.sh <repo-root>   (executable bit may be lost in ZIP; intended mode 0755)
set -euo pipefail
DEST="${1:-.}"
SRC="$(cd "$(dirname "$0")" && pwd)"
echo "Applying FOH package from $SRC into $DEST"
mkdir -p "$DEST/artifacts/isola"
cp -R "$SRC/artifacts/isola/." "$DEST/artifacts/isola/"
if [ -d "$DEST/artifacts/isola/app/-marketing-" ]; then
  rm -rf "$DEST/artifacts/isola/app/(marketing)"
  mv "$DEST/artifacts/isola/app/-marketing-" "$DEST/artifacts/isola/app/(marketing)"
  echo "Renamed app/-marketing- -> app/(marketing)"
fi
echo "Done. Next (Replit): pnpm install && pnpm --filter @workspace/isola typecheck && pnpm --filter @workspace/isola build && pnpm --filter @workspace/isola test"
