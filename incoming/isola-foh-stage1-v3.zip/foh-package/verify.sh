#!/usr/bin/env bash
# Authoritative invocation:  bash verify.sh   (executable bit may be lost in ZIP; intended mode 0755)
set -euo pipefail
cd "$(dirname "$0")"
if [ -d "artifacts/isola/app/-marketing-" ] && [ ! -d "artifacts/isola/app/(marketing)" ]; then
  mv "artifacts/isola/app/-marketing-" "artifacts/isola/app/(marketing)"
  echo "Renamed app/-marketing- -> app/(marketing)"
fi
sha256sum -c SHA256SUMS
echo "OK: $(grep -c '' SHA256SUMS) files verified"
