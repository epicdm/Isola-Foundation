# Front-of-House Launch Readiness — Stage 1 package (corrected v2)

Target: **epicdm/Isola-Foundation**, app **artifacts/isola** (pkg `@workspace/isola`) — Next 15 App Router · React 19 · Tailwind 4 · shadcn/ui · vitest.
Branch: `feat/front-of-house-launch-readiness`. Packet: `xp-front-of-house-launch-readiness`.

## File counts (exact)
- **Physical files in package: 36**
- **Checksum-covered files (SHA256SUMS): 34** — `manifest.json` and `SHA256SUMS` are NOT in the checksum list.

## Integrity — run immediately after unpacking
```bash
bash verify.sh      # renames -marketing- -> (marketing) in place, then sha256sum -c SHA256SUMS
```
Executable bits may be lost in the ZIP, so `bash verify.sh` and `bash apply.sh <repo-root>` are the authoritative invocations (intended modes 0755). `README.md` and `verify.sh` are covered by SHA256SUMS and report OK.

## Route-group path note
This environment cannot store `()` in paths, so `(marketing)` ships as `-marketing-`. `verify.sh` (in place) and `apply.sh` (into repo) restore it. SHA256SUMS is keyed to the `(marketing)` paths and passes after the rename.

## Single source of truth (no duplicated contract data)
`artifacts/isola/contracts/`: `service-adapter.js`, `cta-registry.js`, `analytics-schema.json` (+ `analytics-client.js`, `rehearsal-runner.js`, `rehearsal-evidence.json`). TS bridges in `lib/foh/` import these and derive types:
- `service-adapter.ts` imports `../../contracts/service-adapter.js`, uses `.IsolaServices`, `assertAdapter()` throws if a method is missing.
- `cta-registry.ts` / `analytics.ts` import the JS/JSON contracts.

## CTA phase model
`frontendCalls` (click: createIntent/resumeJourney/supportRequest) · `journeyCalls` (qualify/recommend/requestProposal) · `provisioningCalls` (activate*). Click emits `cta_click`+`intent_created` only; `qualification_started` only when `qualify()` runs; comms-only `assistant:null`. Contact validated (placeholder `wa` rejected).

## Routes (9)
/products, /communications, /assistants, /solutions, /business-line, /hosted-pbx, /connect-pbx, /personal-line, /solutions/smart-front-desk.

## Tests (real Vitest files; run `pnpm --filter @workspace/isola test`)
- `tests/foh-stage1.test.ts` — 11 `it` + 8 `it.each` rows = **19 cases** (bridge incl. `assertAdapter` throws /createIntent/; drift; 8 contact cases; journey incl. strict service_error = error/SERVICE_UNAVAILABLE/retry/correlationId, never pending).
- `tests/harness-mirror.test.ts` — **4 cases** (fixture-exists gate → content mirror; reads `tests/fixtures/foh-app.jsx` at a deterministic path).
- `tests/cta-state.test.tsx` — **6 cases** (SSR render: service-error message + retry + escalation + correlation; success).
- Total **29 Vitest cases** across 3 files.

## Review harness (`review/`)
`foh-site-bundle.html` (self-contained), `foh-app.jsx`, `foh-stage1-diagnostic.txt`. The mirror test reads `tests/fixtures/foh-app.jsx` (identical copy).

## Evidence honesty
`review/foh-stage1-diagnostic.txt` is a **Custom contract diagnostic** (sandbox eval of `contracts/*.js`) — **not** Vitest output: 24/24 checks. Raw `vitest` output must be produced in Replit. NOT claimed here: TypeScript passed, Next build passed, Replit integration passed, routes live, or a commit exists.

## Remaining routes (later stages)
/pricing, /compare, /faq, /demo, /apply, /signup, /support, /privacy, /terms, /pbx-ai-upgrade, /whatsapp-receptionist.
